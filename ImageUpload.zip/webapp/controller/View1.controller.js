sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/Filter",
	"sap/m/MessageBox",
	"sap/ui/model/json/JSONModel",
	"sap/m/Label",
	"sap/m/Token",
	'sap/m/ColumnListItem',
	'sap/m/MessageToast',
], function (Controller) {
	"use strict";
 	const toDataURL = url => fetch(url)
		.then(response => response.blob())
		.then(blob => new Promise((resolve, reject) => {
			const reader = new FileReader()
			reader.onloadend = () => resolve(reader.result)
			reader.onerror = reject
			reader.readAsDataURL(blob)

		}))
	return Controller.extend("Mypas23.ImageUpload.controller.View1", {
		onInit: function () {

		},
		handleUploadPress: function () {
			var oFileUpload = this.getView().byId("fileUploader");
			if (oFileUpload.oFileUpload != null) {

				var f = oFileUpload.oFileUpload.files[0];
				if (f != null) {
					var path = URL.createObjectURL(f);
					var domRef = oFileUpload.getFocusDomRef();
					var file = domRef.files[0];

					toDataURL(path)
						.then(dataUrl => {
							console.log('RESULT:', dataUrl)
							dataUrl = dataUrl.replace('data:image/jpeg;base64,', '');
							var imgdata = {
								"Fname": file.name,
								"Content": dataUrl,
								"ContentX": dataUrl,
								"NotifNum": "",
								"Mimetype": file.type
							};
							resolve(imgdata);

						});

				} else {
					var imgdata = {
						"Fname": '',
						"Content": '',
						"ContentX": '',
						"NotifNum": "",
						"Mimetype": ''
					};
					resolve(imgdata);
				}

			} else {
				var imgdata = {
					"Fname": '',
					"Content": '',
					"ContentX": '',
					"NotifNum": "",
					"Mimetype": ''
				};
	 		resolve(imgdata);
			}

		}
	});
});