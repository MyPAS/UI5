sap.ui.define([
	"Mypas23/ImageUpload/test/unit/controller/View1.controller"
], function () {
	"use strict";
});