sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/core/routing/History",
	"sap/ui/model/Filter",
	"sap/m/MessageBox",
	"sap/ui/model/json/JSONModel",
	"sap/m/Label",
	"sap/m/Token",
	"sap/m/ColumnListItem",
	"sap/m/MessageToast"
], function (Controller, History) {
	"use strict";

	return Controller.extend("Test.Test.controller.View1", {
		onInit: function () {
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			oRouter.getRoute("View2").attachPatternMatched(this.onObjectMatched, this);
		},

		onObjectMatched: function (oEvent) {
		},
			handleUploadComplete: function(oEvent) {
			var sResponse = oEvent.getParameter("response");
			if (sResponse) {
				var sMsg = "";
				var m = /^\[(\d\d\d)\]:(.*)$/.exec(sResponse);
				if (m[1] == "200") {
					sMsg = "Return Code: " + m[1] + "\n" + m[2] + "(Upload Success)";
					oEvent.getSource().setValue("");
				} else {
					sMsg = "Return Code: " + m[1] + "\n" + m[2] + "(Upload Error)";
				}

				MessageToast.show(sMsg);
			}
		},

		handleUploadPress: function() {
			var oFileUploader = this.byId("fileUploader");
			oFileUploader.upload();
		},
				handleInqueryPress: function (oEvent) {

			//	MessageBox.alert("Link was clicked!");
		},
				onNavBack: function () {
				var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
				oRouter.navTo("View1");
			
		}


	});
});