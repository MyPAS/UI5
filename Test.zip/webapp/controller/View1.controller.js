sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/Filter",
	"sap/m/MessageBox",
	"sap/ui/model/json/JSONModel",
	"sap/m/Label",
	"sap/m/Token",
	'sap/m/ColumnListItem',
	'sap/m/MessageToast',
], function (Controller) {
	"use strict";

	return Controller.extend("Test.Test.controller.View1", {
		onInit: function () {
	     	var oModel = new sap.ui.model.json.JSONModel();
			var oTable = this.getView().byId("idMTable");
			oModel.loadData("./model/products.json", "", false);
			oTable.setModel(oModel);
			this.ProductCollection = oModel.oData.ProductCollection;
		},
			handleUploadComplete: function(oEvent) {
			var sResponse = oEvent.getParameter("response");
			if (sResponse) {
				var sMsg = "";
				var m = /^\[(\d\d\d)\]:(.*)$/.exec(sResponse);
				if (m[1] == "200") {
					sMsg = "Return Code: " + m[1] + "\n" + m[2] + "(Upload Success)";
					oEvent.getSource().setValue("");
				} else {
					sMsg = "Return Code: " + m[1] + "\n" + m[2] + "(Upload Error)";
				}

				MessageToast.show(sMsg);
			}
		},

		handleUploadPress: function() {
			var oFileUploader = this.byId("fileUploader");
			oFileUploader.upload();
		},
		handleInqueryPress: function (oEvent) {
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			oRouter.navTo("View2");
		},
	});
});